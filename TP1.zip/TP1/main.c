#include "Headers/auxiliares.h"
int main(){
    srand(time(NULL));
    menu();

    return 0;
}
